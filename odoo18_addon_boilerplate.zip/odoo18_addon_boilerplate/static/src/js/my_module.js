// Example JS module
/** @odoo-module **/
odoo.define('odoo18_addon_boilerplate.MyWidget', function (require) {
    console.log('My Module JS loaded');
});
