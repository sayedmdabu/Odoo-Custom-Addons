{
    'name': 'ORDIA Integration',
    'version': '18.0.1.0.1',
    'category': 'Integration',
    'summary': 'ORDIA API Integration for Cart Management',
    'description': """
        ORDIA Integration Module
        ========================
        * Login with ORDIA API credentials
        * View and search cart data
        * Store cart data in database
        * Real-time API integration
    """,
    'author': 'Md Abu Sayed',
    'website': 'https://www.sagbrain.com',
    'depends': ['base', 'web', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/ordia_login_views.xml',
        'views/ordia_cart_temp_views.xml',
        'views/ordia_cart_views.xml',
        'views/ordia_menus.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
    'external_dependencies': {
        'python': ['requests'],
    },
}